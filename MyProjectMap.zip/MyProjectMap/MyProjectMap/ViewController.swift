//
//  ViewController.swift
//  MyProjectMap
//
//  Created by Филипов ИСИП 20 on 28.03.2022.
//

import UIKit
import MapKit

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {
    
    @IBOutlet weak var mapView: MKMapView!
    
    //Переменные для создания маршрута
    var itemMapFirst: MKMapItem!
    var itemMapSecond: MKMapItem!
    
    //для работы с картой создается manager
    let manager: CLLocationManager = {
        let locationManager = CLLocationManager() //Получение местоположения
        
        locationManager.activityType = .fitness
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.distanceFilter = 1
        locationManager.showsBackgroundLocationIndicator = true
        locationManager.pausesLocationUpdatesAutomatically = true
        
        return locationManager
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        mapView.delegate = self
        manager.delegate = self
        
        authorization()
        pinPosition()
        
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        for location in locations {
            
            print(location.coordinate.latitude)
            print(location.coordinate.longitude)
            itemMapFirst = MKMapItem(placemark: MKPlacemark(coordinate: location.coordinate))
        }
        }
    func authorization () {
        if CLLocationManager.authorizationStatus() == .authorizedAlways || CLLocationManager.authorizationStatus() == .authorizedWhenInUse{
            mapView.showsUserLocation = true
        }
        else{
            manager.requestWhenInUseAuthorization()
        }
    }
    func pinPosition(){
        
        let arrayLet = [62.03, 50.45]
        let arrayLon = [129.73, 30.52]
        
        for number in 0..<arrayLet.count {
           
            let point = MKPointAnnotation()
            point.title = "My point"
            point.coordinate = CLLocationCoordinate2D(latitude: arrayLet[number], longitude: arrayLon[number])
            mapView.addAnnotation(point)
        }
    }
        
    
}

